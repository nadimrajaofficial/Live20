const fetch = require("node-fetch");

module.exports = async (req, res) => {
  const baseUrl = "https://cdn-1.pishow.tv/live/1456/";

  const file = req.query.file;
  const url = baseUrl + file;

  try {
    const response = await fetch(url);
    res.setHeader("Content-Type", response.headers.get("content-type"));
    response.body.pipe(res);
  } catch (error) {
    res.status(500).send("Error fetching segment");
  }
};

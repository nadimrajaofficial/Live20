const fetch = require("node-fetch");

module.exports = async (req, res) => {
  // আপনার আসল M3U8 লিংক
  const original = "https://cdn-1.pishow.tv/live/1456/master.m3u8";
  const baseUrl  = "https://cdn-1.pishow.tv/live/1456/"; // সেগমেন্ট বেস URL

  try {
    const response = await fetch(original);
    let body = await response.text();

    // ts/m4s ফাইলগুলোকে proxy segment এ রূপান্তর করা
    body = body.replace(/(.*\.ts)/g, (match) => `/api/segment?file=${encodeURIComponent(match)}`);
    body = body.replace(/(.*\.m4s)/g, (match) => `/api/segment?file=${encodeURIComponent(match)}`);

    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    res.send(body);
  } catch (error) {
    res.status(500).send("Error fetching m3u8 playlist");
  }
};
